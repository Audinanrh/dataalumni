<div class="box box-success">
	<div class="box-header with-border">
		<div class="box-title"><?php echo $berita['judul'];?></div>
	</div>
	<div class="box-body">
		<?php echo $berita['isi_berita'];?>
	</div>
	<div class="box-footer with-border">
		di post pada : <span class="label bg-green"><?php echo $berita['tgl_berita'];?></span>
	</div>
</div>